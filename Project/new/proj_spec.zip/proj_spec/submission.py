## import modules here 


################# training #################

def train(data, classifier_file):# do not change the heading of the function
    pass # **replace** this line with your code    

################# testing #################

def test(data, classifier_file):# do not change the heading of the function
    pass # **replace** this line with your code